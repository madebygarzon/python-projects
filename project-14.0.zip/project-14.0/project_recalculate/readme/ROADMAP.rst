* Project tasks are written one by one, so this can reduce performance.
