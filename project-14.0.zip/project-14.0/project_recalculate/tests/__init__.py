# See README.rst file on addon root folder for license details

from . import test_project_project
from . import test_project_task
