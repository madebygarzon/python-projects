* ADHOC SA
* `Tecnativa <https://www.tecnativa.com>`_:

  * Vicent Cubells

* Nikul Chaudhary <nikulchaudhary2112@gmail.com>

* `Onestein <https://www.onestein.nl>`_:

  * Dennis Sluijk
