* Oihane Crucelaegui <oihanecrucelaegi@avanzosc.es>
* Pedro M. Baeza <pedro.baeza@serviciosbaeza.com>
* Ana Juaristi <anajuarist@avanzosc.es>
* Vicent Cubells <vicent.cubells@tecnativa.com>
* Rodrigo Ferreira <rodrigosferreira91@gmail.com>
* Damien Bouvy <dbo@odoo.com>
* `CorporateHub <https://corporatehub.eu/>`__

  * Alexey Pelykh <alexey.pelykh@corphub.eu>

* Saran Lim. <saranl@ecosoft.co.th>
* Tharathip Chaweewongphan <tharathipc@ecosoft.co.th>
