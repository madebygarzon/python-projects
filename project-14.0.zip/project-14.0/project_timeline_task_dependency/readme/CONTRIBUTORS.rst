* Dennis Sluijk <d.sluijk@onestein.nl>
* Nikul Chaudhary <nikulchaudhary2112@gmail.com>

* `Tecnativa <https://www.tecnativa.com>`_:

  * Alexandre Díaz
