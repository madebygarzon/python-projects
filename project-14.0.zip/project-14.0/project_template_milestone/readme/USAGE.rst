To use this module, you need to:

#. If milestones are used on the template, then the milestones will also be copied when creating a project from the template.
