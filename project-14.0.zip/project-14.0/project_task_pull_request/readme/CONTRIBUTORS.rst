* Kelly Lougheed <kelly@smdrugstore.com>
* `Tecnativa <https://www.tecnativa.com>`_:

  * Ernesto Tejeda
  * Jairo Llopis

* Ooops404 <https://ooops404.com>

  * Ilyas <irazor147@gmail.com>
