To use this module, you need to:

#. Go to Project -> Configuration -> Project
#. Select a project and, under "Pull Request URIs", select the stages
   where you would like a PR URI to be required
#. Go to Dashboard and select a project
#. Attempt to move one of the project's task without a PR URI into one of
   the stages you selected to require a PR; you will receive a Validation Error
#. To add a PR URI to a task, click on the task and set it in the corresponding field in the header.
