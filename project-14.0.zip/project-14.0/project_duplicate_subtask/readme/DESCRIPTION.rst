This module adds a server action that allows to duplicate a task with its child tasks.
