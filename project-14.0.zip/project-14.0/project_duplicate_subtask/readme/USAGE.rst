To use this module, there are two ways:

#. Go to a task: Action > Duplicate with subtasks.
#. Go to the tasks list view, select the tasks you want to duplicate: Action > Duplicate with subtasks.
