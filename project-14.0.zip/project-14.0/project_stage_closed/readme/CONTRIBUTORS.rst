* Stéphane Bidoul <stephane.bidoul@acsone.eu>
* `Tecnativa <https://www.tecnativa.com>`_:

  * Pedro M. Baeza
  * Luis M. Ontalba
  * Ernesto Tejeda

* Saran Lim. <saranl@ecosoft.co.th>
* Nattapol Sinsuphan<gamso321@gmail.com>
* Pierre Verkest <pierreverkest84@gmail.com>
