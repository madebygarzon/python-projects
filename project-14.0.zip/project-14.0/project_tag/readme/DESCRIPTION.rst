This module add the task tags to the project.
