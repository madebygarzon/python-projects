Add message chatter on the Project form.
