* Carlos Dauden <carlos@incaser.es>
* Sergio Teruel <sergio@incaser.es>
* Duc, Dao Dong <duc.dd@komit-consulting.com> (https://komit-consulting.com)
* `Tecnativa <https://www.tecnativa.com>`_:

  * Ernesto Tejeda
