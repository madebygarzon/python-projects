For setting employee categories at project level:

#. Go to *Project > Projects*.
#. Click on the 3 vertical dots of one of the project kanban cards for
   unfolding options and select "Edit".
#. Put the wanted employee categories on the field "Employee Categories".

For setting employee categories:

#. Go to *Project > All Tasks*.
#. Select or create a new task.
#. Put the wanted employee categories on the field "Employee categories".
#. If there's already some employee categories selected at project level, those
   will be the only selectable ones in the task.
