* `Tecnativa <https://www.tecnativa.com>`_:

  * Pedro M. Baeza
  * Victor M.M. Torres
  * Ernesto Tejeda

* `CorporateHub <https://corporatehub.eu/>`__

  * Alexey Pelykh <alexey.pelykh@corphub.eu>

* Alfadil Tabar <alfadil.tabar@gmail.com>
