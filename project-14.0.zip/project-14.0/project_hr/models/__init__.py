# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl).

from . import project_project
from . import project_task
from . import res_users
from . import hr_employee
